package util;

import java.util.Scanner;

public class Util {
   public static Scanner scanner = new Scanner(System.in);
}
