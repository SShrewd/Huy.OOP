package model;

import util.Util;
public class MovieProduct extends Product {
    private String author;
    private String director;



    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {this.author = author;}

    public String getDirector() {
        return director;
    }

    public void setDirector(String director) {this.director = director;}

    @Override
    public void input(){
        super.input();
        System.out.println("Nhap nha san xuat:");
        author = Util.scanner.nextLine();
        System.out.println("Nhap dao dien:");
        director = Util.scanner.nextLine();
    }
    @Override
    public void output(){
        super.output();
        System.out.println("Nha san xuat: " + author);
        System.out.println("Dao dien: " + director);
    }
}
