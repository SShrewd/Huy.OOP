package dao;

import model.Customer;

import java.sql.ResultSet;

public class CustomerMapper implements IMapper<Customer>{
    @Override
    public Customer mapping(ResultSet resultSet) {
        return null;
    }
}
